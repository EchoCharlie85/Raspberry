#pragma once

#include "drivers/as7262/as7262.hpp"

namespace pimoroni {

  typedef AS7262 BreakoutAS7262;
}
